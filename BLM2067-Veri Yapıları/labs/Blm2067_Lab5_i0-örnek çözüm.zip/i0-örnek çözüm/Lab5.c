#include <stdio.h>
#include<stdlib.h>

int saat=1;
struct c{
    int memur;
    struct c* next;
    struct c* prev;
    int sure; //0 ekle
    int isleminBittigiZaman; //0 ekle
    int isBusy;
};

struct q{
    int musteri;
    int kacinciDk, islemDk;
    int bekleme; //0 ekle
    int memurA;
    struct q* next;
};


int main() {
    struct c* root=NULL;
    for(int i=1;i<=6;i++)
    {
        if(root==NULL) {
            root = (struct c*)malloc(sizeof(struct c));
            root->memur=i;
            root->isBusy=0; root->sure=0; root->isleminBittigiZaman=0;
            root->next=NULL;
            root->prev=NULL;
        }
        else
        {
            struct c *iter;
            iter=root;
            while(iter->next != NULL)
            {
                iter=iter->next;
            }
            struct c* temp= (struct c*)malloc(sizeof(struct c));
            iter->next=temp;
            temp->prev=iter;
            temp->memur=i;
            temp->isBusy=0; // 0 musait  1 dolu
            temp->sure=0; temp->isleminBittigiZaman=0;
            temp->next=NULL;
        }
    }

    struct c* rootCP=root;
    while(rootCP->next!=NULL)
    {
        rootCP=rootCP->next;  //rootCP nin en son kutusunda
    }

   struct c* rootC= root; //rootun değerini kaybetmemek ıcın

   struct q* rootQ=(struct q*)malloc(sizeof(struct q));
   struct q* temp=rootQ;
   int no,kacinciDk,islemDk;
   scanf("%d",&no);
   while(no!=-1)
   {
       scanf("%d %d",&kacinciDk,&islemDk);
       temp->musteri=no;
       temp->kacinciDk=kacinciDk;
       temp->islemDk=islemDk;
       temp->bekleme=0; //kontrol mekanizması eklemeyi unutma
       temp->memurA=0;
       scanf("%d",&no);
       if(no!= -1){
       temp->next=(struct q*)malloc(sizeof(struct q));
       temp=temp->next;}
       else
           temp->next=NULL;
   }

  temp=rootQ;

    while(temp!= NULL)
    {   struct c* iter=rootCP;
        while(temp->kacinciDk+temp->bekleme<=saat)
        {
            iter=rootCP;
            while (iter != NULL) {
                if (iter->isBusy == 1)iter = iter->prev;
                else break;
            }
             if(iter != NULL) {
                 if (iter->isBusy == 0)
                 {
                     if (iter->isleminBittigiZaman <= saat)
                     {
                         iter->isBusy = 1;
                         iter->isleminBittigiZaman = temp->kacinciDk + temp->islemDk + temp->bekleme;
                         iter->sure += temp->islemDk;
                         temp->memurA = iter->memur;
                         //saate dikkat et printf
                         printf("%d %d %d %d %d\n", temp->musteri, temp->memurA, saat,
                                saat+temp->islemDk, saat-temp->kacinciDk);
                     }
                 }
             }
            if(iter==NULL)
            {
                saat++;
                temp->bekleme=saat-temp->kacinciDk;
            while(rootC != NULL)
            {
            if(rootC->isleminBittigiZaman==saat)
                rootC->isBusy=0;

               rootC=rootC->next;
            }
            rootC=root;
            }

            else temp=temp->next;
           //iter=iter->prev;
            if(temp==NULL) break;
        }

        if (temp != NULL)
        {
            saat = temp->kacinciDk + temp->bekleme;
        }
        
        while(rootC != NULL)
        {
            if(rootC->isleminBittigiZaman==saat)
                rootC->isBusy=0;

            rootC=rootC->next;
        }
        
        rootC=root;
    }

    printf("\n");
    while(rootCP != NULL) //memurları yazdıgım kısım
    {
        printf("%d %d\n",rootCP->memur,rootCP->sure);
        rootCP=rootCP->prev;
    }
    return 0;
}
