struct nodeClass
{
	int classID;
	double classMidtermAverage;
	struct nodeClass *next;
	struct nodeStudent *studentPtr;
};

struct nodeStudent
{
	int studentID;
	int midterm;
	struct nodeStudent *next;
};


void gezinti(struct nodeClass *head,int id,int midterm)
{
 struct nodeStudent *temp = (struct nodeStudent*)malloc(sizeof(struct nodeStudent));

 
     if((head)->studentPtr == NULL)
     {
         temp->next = NULL;
         temp->midterm=midterm;
         temp->studentID=id;
         (head)->studentPtr = temp;
         return;
     }
     

     
     if(((head)->studentPtr->midterm) < midterm)
     {
         temp-> next = (head)->studentPtr;
         temp->studentID = id;
         temp->midterm = midterm;

         (head)->studentPtr = temp; //rootu döndürüyor
         return;
     }

     struct nodeStudent* iter = (struct nodeStudent*)malloc(sizeof(struct nodeStudent));
     struct nodeStudent* root = (struct nodeStudent*)malloc(sizeof(struct nodeStudent));
     iter = (head)->studentPtr;
     while(iter->next != NULL && ((iter->next->midterm) > midterm || (iter->next->midterm)== midterm))
     {   root= iter;
         iter = iter -> next;
     }
     if((iter->midterm) > midterm)
     {
     temp->next = iter->next;
     temp->studentID=id;
     temp->midterm=midterm;
     iter->next = temp;
     return;
     }
     else if((iter->midterm)== midterm)
     {
      if( iter->studentID < id)
      {
       temp->next = iter->next;
       temp->studentID=id;
       temp->midterm = midterm;
       
       iter->next = temp;
       return;
      } 
      if(iter->studentID > id)
      {
       root->next = temp;
       temp->studentID=id;
       temp->midterm = midterm;
       temp->next = iter;
       return;
      }
      } //  return;

}

void insert(struct nodeClass **head,int id,int midterm)
{
 if((*head)== NULL)
 {
    (*head) = (struct nodeClass*)malloc(sizeof(struct nodeClass));
    (*head)->classID= 1;
     struct nodeClass* head2 = (struct nodeClass*)malloc(sizeof(struct nodeClass));
     (*head)->next=head2;
     head2->classID=2;
     struct nodeClass* head3 = (struct nodeClass*)malloc(sizeof(struct nodeClass));
     head2->next = head3;
     head3->classID=3;
     struct nodeClass* head4 = (struct nodeClass*)malloc(sizeof(struct nodeClass));
     head3->next = head4;
     head4->classID=4;
     head4->next=NULL;
 }
 
   // struct nodeStudent *temp = (struct nodeStudent*)malloc(sizeof(struct nodeStudent)); 
    struct nodeClass *root =(struct nodeClass*)malloc(sizeof(struct nodeClass));
    
    if(id < 70000)
    {
     root=(*head);
     gezinti(root,id,midterm);
     return;
    }
    else if(id>70000 && id<80000)
    {
     root=(*head)->next;
     gezinti(root,id,midterm);
     return;
    }
    else if(id>80000 && id<90000)
    {
     root=(*head)->next->next;
     gezinti(root,id,midterm);
     return;
    }
    else
    {
     root=(*head)->next->next->next;
     gezinti(root,id,midterm);
     return;
    }
    
}


void computeClassAverage(struct nodeClass *head)
{
int toplam=0, counter=0;
struct nodeStudent* temp;
	temp= head->studentPtr;
	while(temp != NULL)
	{ 
	  toplam += temp->midterm;
	  counter++;
	  temp = temp->next;
	}
	head->classMidtermAverage=(double)toplam/counter;

toplam=0; counter=0;
//temp=(struct nodeStudent*)malloc(sizeof(struct nodeStudent));
        temp= head->next->studentPtr;
        while(temp != NULL)
        {   
    
        toplam += temp->midterm;
        counter++;
        temp = temp->next;
        }
        head->next->classMidtermAverage=(double)toplam/counter;

toplam=0; counter=0;
//temp=(struct nodeStudent*)malloc(sizeof(struct nodeStudent));
       temp= head->next->next->studentPtr;
       while(temp  != NULL)
       {
        toplam += temp->midterm;
        counter++;
        temp = temp->next;
       }
       head->next->next->classMidtermAverage=(double)toplam/counter;

toplam=0; counter=0;
//temp=(struct nodeStudent*)malloc(sizeof(struct nodeStudent));
       temp= head->next->next->next->studentPtr;
       while(temp != NULL)
       {
        toplam += temp->midterm;
        counter++;
        temp = temp->next;
       }
       head->next->next->next->classMidtermAverage=(double)toplam/counter;
}



void printAll(struct nodeClass *head)
{
    printf("%d %.2f\n",head->classID,head->classMidtermAverage);
    while(head->studentPtr !=NULL)
    {
        printf("%d %d\n",head->studentPtr->studentID, head->studentPtr->midterm);
        head->studentPtr = head->studentPtr->next;
    }

    printf("%d %.2f\n",head->next->classID, head->next->classMidtermAverage);
    while(head->next->studentPtr !=NULL)
    {
        printf("%d %d\n",head->next->studentPtr->studentID,head->next->studentPtr->midterm);
        head->next->studentPtr = head->next->studentPtr->next;
    }

    struct nodeClass* iter = head->next->next;

    printf("%d %.2f\n",iter->classID,iter->classMidtermAverage);
    while (iter->studentPtr != NULL)
    {
        printf("%d %d\n",iter->studentPtr->studentID,iter->studentPtr->midterm);
        iter->studentPtr= iter->studentPtr->next;
    }

    iter = iter->next;
    printf("%d %.2f\n",iter->classID, iter->classMidtermAverage);
    while (iter->studentPtr != NULL)
    {
        printf("%d %d\n",iter->studentPtr->studentID,iter->studentPtr->midterm);
        iter->studentPtr= iter->studentPtr->next;
    }

}

// You must write all the function definitions to be used in this lab into this file.
// You may also write other functions that may be called from our functions.
// Do not make any changes to the main.c file.
// Upload function.h file to the system as StudentNumber.h.



