#include<stdio.h>
#define size 15
int count=0;  //evrensel dikkat
void print(char array[size][size]);
void yanBul(char array[size][size],char word[20],int length);
void yatayBul(char array[size][size],char word[20],int length);
void solSagAsagi(char array[size][size],char word[20],int length);
void solSagYukari(char array[size][size],char word[20],int length);
int main(){
        char arr[size][size], arr2[size*size];
        int k=0;
	for(int i=0;i<size;i++)
	{
	 for(int j=0;j<size;j++){
	 	scanf("%c",&arr[i][j]);
	 	scanf("%c",&arr2[k++]);
	 }	
	}  
	char isim[20]; int uzunluk=0; 
	scanf("%s",isim);
	for(int i=0;isim[i]!= '\0';i++) { uzunluk++; }

        char isim2[uzunluk];
        for(int i=0;i<uzunluk;i++){
         isim2[i]=isim[uzunluk-i-1];
        }
       // printf("%s",word2);
        
        
        yanBul(arr,isim,uzunluk);
        yanBul(arr,isim2,uzunluk);
        yatayBul(arr,isim,uzunluk);
        yatayBul(arr,isim2,uzunluk);
        solSagAsagi(arr,isim,uzunluk);
        solSagAsagi(arr,isim2,uzunluk);
        solSagYukari(arr,isim,uzunluk);
        solSagYukari(arr,isim2,uzunluk);  
        
        
        if(count==0) {
        for(int i=0;i<size;i++) 
        {
          for(int j=0;j<size;j++) printf("*");
          printf("\n");
        }
        }
      return 0;  
}

void print(char array[size][size])
{ 
	for(int i=0;i<size;i++){     //Tabloyu bastırıyor
		for(int j=0;j<size;j++){
			printf("%c",array[i][j]);
		}
		printf("\n");
	}	
}

void yanBul(char array[size][size],char word[20],int length)
{ 
     for(int i = 0;i < size;i++)
	{
		for(int j = 0;j < size;j++)
		{	
			if(array[i][j] == word[0] && (j + length <= size))
			{
				int row = i;
				int column = j;
				
				for(int k = 1;k < length;k++)
				{
					if(array[row][column + k] == word[k] && k != length - 1)
					continue; //döngü kontrol

			/*print*/		if(k == length - 1 && word[k] == array[i][j + k])  //buldu
					{
						for(int x = 0;x < 15;x++)
						{
							for(int t = 0;t < 15;t++)
							{
								array[x][t] = '*';
							}
						}

						for(int u = 0;u < length;u++)
						{
							array[row][column + u] = word[u];
						}						
						
						print(array);
						count++;  //!!!!!!!!!
					}
					else break;  //!!!!!!
					
				}
			} } }
}

void yatayBul(char array[size][size],char word[20],int length)
{
	for(int i=0;i<size;i++)
	{
	  for(int j=0;j<size;j++)
	  {
	    if(array[i][j]==word[0] && (i+length<=size))
	    {
	    	int row=i; int column=j;
	    	for(int k=1;k<length;k++)
	    	{
	           if(array[i+k][j]==word[k] && k!= length-1) 
	           continue; //döngü kontrol
                   if(k == length - 1 && word[k] == array[i+k][j])
					{
						for(int x = 0;x < 15;x++)
						{
							for(int t = 0;t < 15;t++)
							{
								array[x][t] = '*';
							}
						}

						for(int u = 0;u < length;u++)
						{
							array[row+u][column] = word[u];
						}						
						
						print(array);
						count++;  
					}else break; }}}}
}

void solSagAsagi(char array[size][size],char word[20],int length)
{
int k=0;
	for(int i=0;i<size;i++)
	{
	  for(int j=0;j<size;j++)
	  {
	    if(array[i][j]==word[0] && (i+length<=size)&& (j+length<=size) )  // word[k] olmuyor dikkat et!
	    {
	    	int row=i; int column=j;
	    	for(k=1;k<length;k++)
	    	{
	           if(array[i+k][j+k]==word[k] && k!= length-1) 
	           continue; //döngü kontrol
                   if(k == length - 1 && word[k] == array[i+k][j + k])
					{
						for(int x = 0;x < size;x++)
						{
							for(int t = 0;t < size;t++)
							{
								array[x][t] = '*';
							}
						}

						for(int l = 0;l < length;l++)
						{
							array[row+l][column+l] = word[l];
						}						
						
						print(array);
						count++;  
					} else break; }}}}

}

void solSagYukari(char array[size][size],char word[20],int length)
{
int k=0;
	for(int i=0;i<size;i++)
	{
	  for(int j=0;j<size;j++)
	  {
	    if(array[i][j]==word[0] && (i-length>=-1)&& (j+length<=size))
	    {
	    	int row=i; int column=j;
	    	for(k=1;k<length;k++)
	    	{
	           if(array[row-k][column+k]==word[k] && k!= length-1) 
	           continue;   //döngü kontrol
                   if(k == length - 1 && word[k] == array[i-k][j + k])
					{ 
						for(int x = 0;x < 15;x++)
						{
							for(int t = 0;t < 15;t++)
							{
								array[x][t] = '*';
							}
						}

						for(int l = 0;l < length;l++)
						{
							array[row-l][column+l] = word[l];
						}						
						
						print(array);
						count++;  
					} else break; }}}}

}






