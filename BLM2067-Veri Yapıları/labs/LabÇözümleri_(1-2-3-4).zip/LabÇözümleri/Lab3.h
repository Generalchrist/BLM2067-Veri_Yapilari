struct nodeFB
{
    int id;
    int age;
    struct nodeFB *next;
};

struct nodeGS
{
    int id;
    struct nodeGS *next;
};

struct newNodeFB
{
    int id;
    int age;
    struct newNodeGS *next;
};

struct newNodeGS
{
    int id;
    struct newNodeFB *next;
};

void insertFB(struct nodeFB ** r, int id, int age)
{
    struct nodeFB *temp = (struct nodeFB*)malloc(sizeof(struct nodeFB));
    if( (*r) == NULL)
    {
        temp->next = NULL;
        temp->id = id;
        temp->age = age;

        (*r) = temp; // *r adresine tempin adresini koydum
        return;
    }
    if((*r)->id > id) // ilk eleman ile ikinciyi inceliyor
    {
        temp->next= (*r);
        temp->id = id;
        temp->age = age;

        (*r) = temp; //rootu döndürüyor
        return;
    }

    struct nodeFB* iter;
    iter = (*r);
    while(iter->next != NULL && iter->next->id < id)
    {
        iter = iter->next;
    }
    temp->next = iter ->next;
    iter->next = temp;
    temp-> id = id;
    temp -> age = age;
    //return r ;

}

void insertGS(struct nodeGS** r, int id)
{
    struct nodeGS *temp = (struct nodeGS*)malloc(sizeof(struct nodeGS));
    if( (*r) == NULL)
    {
        temp->next = NULL;
        temp->id = id;

        (*r) = temp; // *r adresine tempin adresini koydum
        return;
    }
    if((*r)->id < id) // ilk eleman ile ikinciyi inceliyor
    {
        temp->next= (*r);
        temp->id = id;

        (*r) = temp; //rootu döndürüyor
        return;
    }

    struct nodeGS* iter;
    iter = (*r);
    while(iter->next != NULL && iter->next->id > id)
    {
        iter = iter->next;
    }
    temp->next = iter ->next;
    iter->next = temp;
    temp-> id = id;

    //return r ;

}

void printFB(struct nodeFB* r)
{
    while(r !=NULL)
    {
        printf("%d %d\n",r->id, r->age);
        r = r->next;
    }
    printf("\n");
}

void printGS(struct nodeGS* r)
{
    while(r !=NULL)
    {
        printf("%d\n",r->id);
        r = r->next;
    }
    printf("\n");
}

void createFinalList(struct newNodeFB** startNewFB, struct nodeFB* startFB, struct nodeGS* startGS)
{
    struct newNodeFB* fb= (struct newNodeFB*)malloc(sizeof(struct newNodeFB));
 if((*startNewFB) == NULL)
 {
     (*startNewFB) = fb;
 }

 while(startFB != NULL || startGS != NULL)
 {
     struct newNodeGS* gs = (struct newNodeGS*)malloc(sizeof(struct newNodeGS));
     fb->id = startFB->id;
     fb->age = startFB->age;
     fb->next = gs;

     gs->id = startGS->id;
     fb= (struct newNodeFB*)malloc(sizeof(struct newNodeFB));
     gs->next = fb;
     startGS = startGS->next;
     startFB = startFB->next;

 }

}

void printAll(struct newNodeFB *startNewFB) {
    struct newNodeFB* iter = (struct newNodeFB*)malloc(sizeof(struct newNodeFB));
    struct newNodeGS* iterGS = (struct newNodeGS*)malloc(sizeof(struct newNodeGS));
iter = startNewFB;
    while(iter->next != NULL)
    {
        printf("%d %d\n",iter->id,iter->age);
        iterGS =iter->next;
        printf("%d\n",iterGS->id);
        
        iter=iterGS->next;
    }
}
// Bu lab kapsaminda kullanilacak butun fonksiyon tanimlarini bu dosyanin icine yazmaniz gerekmektedir.
// Tanimlanmasi zorunlu fonksiyonlar icerisinden kendi tanimayacaginiz baska fonksiyonlari cagirabilirsiniz.
// main.c dosyasinda bir degisiklik yapmayiniz.
// Sisteme function.h dosyasinin ismini OgrenciNumarasi.h olarak yukleyiniz.


